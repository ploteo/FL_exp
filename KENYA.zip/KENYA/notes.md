8 Luglio 2021

- Implementare pseudo-randomizzazione
  - a.       PGG – TP – RP
  - b.       PGG – RP – TP
  - c.       TP – RP - PGG
  - d.       RP – TP - PGG


- Mettere  a posto il final display quando le sequenze delle app sono casuali